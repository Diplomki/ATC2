<?php
abstract class Config
{
    const HOST = '127.0.0.1';
    const DB_NAME = 'atc';
    const DB_USER = 'root';
    const DB_PASSWORD = 'root';
}